package com.namrata.railway;

import com.namrata.railway.model.Train;
import com.namrata.railway.repository.TrainRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.time.LocalTime;

// Adds a few sample trains the first time the app starts with an empty database.
@Component
public class DataSeeder implements CommandLineRunner {

    private final TrainRepository trainRepository;

    public DataSeeder(TrainRepository trainRepository) {
        this.trainRepository = trainRepository;
    }

    @Override
    public void run(String... args) {
        if (trainRepository.count() > 0) {
            return;
        }
        trainRepository.save(new Train("12001", "Bengaluru - Hubli Express", "Bengaluru", "Hubli",
                LocalTime.of(22, 0), 120, new BigDecimal("450.00")));
        trainRepository.save(new Train("12002", "Hubli - Bengaluru Express", "Hubli", "Bengaluru",
                LocalTime.of(21, 30), 120, new BigDecimal("450.00")));
        trainRepository.save(new Train("12003", "Bengaluru - Pune Superfast", "Bengaluru", "Pune",
                LocalTime.of(18, 15), 150, new BigDecimal("720.00")));
        trainRepository.save(new Train("12004", "Pune - Hyderabad Express", "Pune", "Hyderabad",
                LocalTime.of(16, 45), 100, new BigDecimal("560.00")));
    }
}
