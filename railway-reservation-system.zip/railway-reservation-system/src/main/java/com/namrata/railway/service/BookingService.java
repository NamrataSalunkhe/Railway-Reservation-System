package com.namrata.railway.service;

import com.namrata.railway.dto.BookingRequest;
import com.namrata.railway.model.Booking;
import com.namrata.railway.model.BookingStatus;
import com.namrata.railway.model.Train;
import com.namrata.railway.repository.BookingRepository;
import com.namrata.railway.repository.TrainRepository;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.math.BigDecimal;
import java.util.UUID;

@Service
public class BookingService {

    private final BookingRepository bookingRepository;
    private final TrainRepository trainRepository;

    public BookingService(BookingRepository bookingRepository, TrainRepository trainRepository) {
        this.bookingRepository = bookingRepository;
        this.trainRepository = trainRepository;
    }

    @Transactional
    public Booking book(BookingRequest request) {
        Train train = trainRepository.findByIdForUpdate(request.trainId())
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Train not found"));

        if (train.getAvailableSeats() < request.seats()) {
            throw new ResponseStatusException(HttpStatus.CONFLICT,
                    "Only " + train.getAvailableSeats() + " seats available");
        }

        train.setAvailableSeats(train.getAvailableSeats() - request.seats());
        trainRepository.save(train);

        BigDecimal totalFare = train.getFarePerSeat().multiply(BigDecimal.valueOf(request.seats()));
        Booking booking = new Booking(generatePnr(), train, request.passengerName(),
                request.passengerAge(), request.seats(), totalFare);
        return bookingRepository.save(booking);
    }

    public Booking getByPnr(String pnr) {
        return bookingRepository.findByPnr(pnr)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Booking not found"));
    }

    @Transactional
    public Booking cancel(String pnr) {
        Booking booking = getByPnr(pnr);
        if (booking.getStatus() == BookingStatus.CANCELLED) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "Booking is already cancelled");
        }

        // Lock the train row, then give the seats back.
        Train train = trainRepository.findByIdForUpdate(booking.getTrain().getId())
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Train not found"));
        train.setAvailableSeats(train.getAvailableSeats() + booking.getSeatsBooked());
        trainRepository.save(train);

        booking.setStatus(BookingStatus.CANCELLED);
        return bookingRepository.save(booking);
    }

    private String generatePnr() {
        return UUID.randomUUID().toString().replace("-", "").substring(0, 10).toUpperCase();
    }
}
