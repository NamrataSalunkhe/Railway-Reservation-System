package com.namrata.railway.controller;

import com.namrata.railway.model.Train;
import com.namrata.railway.service.TrainService;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/trains")
public class TrainController {

    private final TrainService trainService;

    public TrainController(TrainService trainService) {
        this.trainService = trainService;
    }

    // GET /api/trains?source=Bengaluru&destination=Hubli
    @GetMapping
    public List<Train> search(@RequestParam String source, @RequestParam String destination) {
        return trainService.search(source, destination);
    }

    @GetMapping("/{id}")
    public Train getById(@PathVariable Long id) {
        return trainService.getById(id);
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Train addTrain(@RequestBody Train train) {
        return trainService.addTrain(train);
    }
}
