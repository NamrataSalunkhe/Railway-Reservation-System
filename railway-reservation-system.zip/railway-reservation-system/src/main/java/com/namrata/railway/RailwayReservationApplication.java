package com.namrata.railway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RailwayReservationApplication {
    public static void main(String[] args) {
        SpringApplication.run(RailwayReservationApplication.class, args);
    }
}
