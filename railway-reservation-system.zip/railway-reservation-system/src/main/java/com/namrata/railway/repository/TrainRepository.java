package com.namrata.railway.repository;

import com.namrata.railway.model.Train;
import jakarta.persistence.LockModeType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface TrainRepository extends JpaRepository<Train, Long> {

    List<Train> findBySourceIgnoreCaseAndDestinationIgnoreCase(String source, String destination);

    boolean existsByTrainNumber(String trainNumber);

    // Locks the row so two people cannot book the last seats at the same time.
    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("select t from Train t where t.id = :id")
    Optional<Train> findByIdForUpdate(@Param("id") Long id);
}
