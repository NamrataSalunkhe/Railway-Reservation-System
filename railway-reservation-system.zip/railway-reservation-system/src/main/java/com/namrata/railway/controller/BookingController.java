package com.namrata.railway.controller;

import com.namrata.railway.dto.BookingRequest;
import com.namrata.railway.model.Booking;
import com.namrata.railway.service.BookingService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/bookings")
public class BookingController {

    private final BookingService bookingService;

    public BookingController(BookingService bookingService) {
        this.bookingService = bookingService;
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Booking book(@Valid @RequestBody BookingRequest request) {
        return bookingService.book(request);
    }

    @GetMapping("/{pnr}")
    public Booking getByPnr(@PathVariable String pnr) {
        return bookingService.getByPnr(pnr);
    }

    // DELETE /api/bookings/{pnr} cancels the booking and returns the seats
    @DeleteMapping("/{pnr}")
    public Booking cancel(@PathVariable String pnr) {
        return bookingService.cancel(pnr);
    }
}
