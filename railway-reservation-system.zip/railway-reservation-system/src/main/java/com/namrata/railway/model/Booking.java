package com.namrata.railway.model;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name = "bookings")
public class Booking {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true)
    private String pnr;

    @ManyToOne(optional = false)
    @JoinColumn(name = "train_id")
    private Train train;

    @Column(nullable = false)
    private String passengerName;

    private int passengerAge;

    private int seatsBooked;

    private BigDecimal totalFare;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private BookingStatus status;

    private LocalDateTime bookedAt;

    public Booking() {
    }

    public Booking(String pnr, Train train, String passengerName, int passengerAge,
                   int seatsBooked, BigDecimal totalFare) {
        this.pnr = pnr;
        this.train = train;
        this.passengerName = passengerName;
        this.passengerAge = passengerAge;
        this.seatsBooked = seatsBooked;
        this.totalFare = totalFare;
        this.status = BookingStatus.CONFIRMED;
        this.bookedAt = LocalDateTime.now();
    }

    public Long getId() { return id; }
    public String getPnr() { return pnr; }
    public Train getTrain() { return train; }
    public String getPassengerName() { return passengerName; }
    public int getPassengerAge() { return passengerAge; }
    public int getSeatsBooked() { return seatsBooked; }
    public BigDecimal getTotalFare() { return totalFare; }
    public BookingStatus getStatus() { return status; }
    public void setStatus(BookingStatus status) { this.status = status; }
    public LocalDateTime getBookedAt() { return bookedAt; }
}
