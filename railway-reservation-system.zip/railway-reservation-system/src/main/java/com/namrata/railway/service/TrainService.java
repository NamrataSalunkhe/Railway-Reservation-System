package com.namrata.railway.service;

import com.namrata.railway.model.Train;
import com.namrata.railway.repository.TrainRepository;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@Service
public class TrainService {

    private final TrainRepository trainRepository;

    public TrainService(TrainRepository trainRepository) {
        this.trainRepository = trainRepository;
    }

    public List<Train> search(String source, String destination) {
        return trainRepository.findBySourceIgnoreCaseAndDestinationIgnoreCase(source, destination);
    }

    public Train getById(Long id) {
        return trainRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Train not found"));
    }

    public Train addTrain(Train train) {
        if (trainRepository.existsByTrainNumber(train.getTrainNumber())) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "Train number already exists");
        }
        train.setAvailableSeats(train.getTotalSeats());
        return trainRepository.save(train);
    }
}
