package com.namrata.railway.model;

public enum BookingStatus {
    CONFIRMED,
    CANCELLED
}
