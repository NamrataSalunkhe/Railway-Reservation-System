# Railway Reservation System

A REST API for searching trains and booking or cancelling tickets, built with Java, Spring Boot and MySQL.

## Features
- Search trains by source and destination
- Book tickets with fare calculation and a unique PNR
- View a booking by PNR
- Cancel a booking and return the seats to the train
- Row locking on the train record so the last seats cannot be double-booked

## Tech stack
Java 17, Spring Boot 3, Spring Data JPA, MySQL (H2 for quick local runs), Maven

## Run it

**With MySQL:** set your username and password in `src/main/resources/application.properties`, then:
```
mvn spring-boot:run
```
The `railway_db` database is created automatically.

**Without MySQL (in-memory H2):**
```
mvn spring-boot:run -Dspring-boot.run.profiles=h2
```
Sample trains are added on first start. The app runs at http://localhost:8080.

## API

| Method | Endpoint | What it does |
|--------|----------|--------------|
| GET | `/api/trains?source=Bengaluru&destination=Hubli` | Search trains |
| GET | `/api/trains/{id}` | Get one train |
| POST | `/api/trains` | Add a train |
| POST | `/api/bookings` | Book tickets |
| GET | `/api/bookings/{pnr}` | View a booking |
| DELETE | `/api/bookings/{pnr}` | Cancel a booking |

Example booking request:
```json
POST /api/bookings
{
  "trainId": 1,
  "passengerName": "Asha Rao",
  "passengerAge": 28,
  "seats": 2
}
```

## Project structure
```
controller/   REST endpoints
service/      booking and train logic (transactions, seat checks)
repository/   Spring Data JPA repositories
model/        Train, Booking, BookingStatus entities
dto/          request objects with validation
```
